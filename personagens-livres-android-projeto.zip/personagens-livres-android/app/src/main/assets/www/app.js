const defaults = [
 {id:"luna",name:"Luna",desc:"Astrônoma que adora descobrir coisas novas.",personality:"Curiosa, gentil e fascinada pelo espaço.",emoji:"🌙"},
 {id:"kai",name:"Kai",desc:"Aventureiro que conhece histórias de lugares distantes.",personality:"Corajoso, bem-humorado e criativo.",emoji:"🧭"},
 {id:"bia",name:"Bia",desc:"Inventora que transforma ideias em projetos.",personality:"Prática, animada e gosta de explicar como as coisas funcionam.",emoji:"⚙️"}
];
let characters = JSON.parse(localStorage.getItem("pl_chars")||"null") || defaults;
let active = null;
const $ = id => document.getElementById(id);
const save = () => {localStorage.setItem("pl_chars",JSON.stringify(characters));};
function history(id){return JSON.parse(localStorage.getItem("pl_chat_"+id)||"[]")}
function saveHistory(id,arr){localStorage.setItem("pl_chat_"+id,JSON.stringify(arr))}
function renderCards(){
 $("characterList").innerHTML="";
 characters.forEach(c=>{
  const el=document.createElement("article");el.className="card";
  const emoji=document.createElement("div");emoji.className="avatar";emoji.textContent=c.emoji||"✨";
  const h=document.createElement("h3");h.textContent=c.name;
  const p=document.createElement("p");p.textContent=c.desc||"Personagem personalizado";
  const b=document.createElement("button");b.className="primary";b.textContent="Conversar";b.onclick=()=>openChat(c.id);
  el.append(emoji,h,p,b);$("characterList").append(el);
 });
}
function addBubble(who,text){const b=document.createElement("div");b.className="bubble "+who;b.textContent=text;$("messages").append(b);$("messages").scrollTop=$("messages").scrollHeight;}
function openChat(id){
 active=characters.find(c=>c.id===id);if(!active)return;
 $("home").classList.add("hidden");$("chat").classList.remove("hidden");
 $("chatName").textContent=active.name;$("chatDesc").textContent=active.desc||"";
 $("messages").innerHTML="";history(id).forEach(m=>addBubble(m.who,m.text));
 if(!history(id).length)addBubble("bot",`Oi! Eu sou ${active.name}. Sobre o que você gostaria de conversar?`);
}
function reply(message,c){
 const m=message.toLowerCase();
 if(/^(oi|olá|ola|e aí|eai|hey)\b/.test(m))return `Oi! Que bom conversar com você. ${c.personality||""}`;
 if(m.includes("?"))return `Boa pergunta! Eu sou ${c.name}, então vou pensar nisso com você. O que você já sabe sobre esse assunto?`;
 if(m.includes("obrigad"))return "Por nada! Pode continuar, estou acompanhando a conversa.";
 if(m.includes("tchau"))return "Até mais! Quando quiser, podemos continuar nossa conversa.";
 return `Interessante! Você pode me contar um pouco mais? Como isso se relaciona com o que você está pensando?`;
}
$("sendForm").addEventListener("submit",e=>{
 e.preventDefault();const input=$("messageInput"),value=input.value.trim();if(!value||!active)return;
 const arr=history(active.id);arr.push({who:"user",text:value});addBubble("user",value);input.value="";
 const answer=reply(value,active);arr.push({who:"bot",text:answer});saveHistory(active.id,arr);addBubble("bot",answer);
});
$("newCharacter").onclick=()=>{$("characterForm").reset();$("characterDialog").showModal()};
$("saveCharacter").onclick=e=>{
 const name=$("charName").value.trim();if(!name){e.preventDefault();return;}
 const c={id:"c"+Date.now(),name,desc:$("charDesc").value.trim(),personality:$("charPersonality").value.trim(),emoji:"✨"};
 characters.push(c);save();renderCards();
};
$("back").onclick=()=>{$("chat").classList.add("hidden");$("home").classList.remove("hidden");active=null;};
$("clearChat").onclick=()=>{if(active){localStorage.removeItem("pl_chat_"+active.id);openChat(active.id);}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
renderCards();